This is the Altair Library SDK for Linux & MacOS.

It supports x86-32, x86-64, arm64, and armhf architectures.
